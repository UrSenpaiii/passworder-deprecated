package com.myself.passworder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassworderApiApplicationTests {

    @Test
    void contextLoads() {
    }

}