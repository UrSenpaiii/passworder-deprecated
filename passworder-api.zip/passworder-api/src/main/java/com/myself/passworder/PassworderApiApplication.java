package com.myself.passworder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassworderApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PassworderApiApplication.class, args);
    }

}